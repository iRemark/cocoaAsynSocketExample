//
//  main.m
//  ServerExample
//
//  Created by lc-macbook pro on 2017/10/23.
//  Copyright © 2017年 http://www.cnblogs.com/saytome/. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
